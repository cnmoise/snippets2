package com.example.claud.momappreborn;

import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.design.widget.TabLayout;
import android.util.Log;

public class ControlRoom extends AppCompatActivity implements NewPresetDialog.NewPresetDialogListener, TimerFragment.TimerFragmentListener {

    private boolean globalTimerStatus;
    private CountDownTimer globalCountDownTimer;

    private int[] imageResId = {
            R.drawable.ic_one,
            R.drawable.ic_two,
            R.drawable.ic_three };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control_room);

        // Get the ViewPager and set it's PagerAdapter so that it can display items
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        SampleFragmentPagerAdapter pagerAdapter =
                new SampleFragmentPagerAdapter(getSupportFragmentManager(), ControlRoom.this);
        viewPager.setAdapter(pagerAdapter);

        //sets context to the activity we're currently in

        // Give the TabLayout the ViewPager
        TabLayout tabLayout = (TabLayout) findViewById(R.id.sliding_tabs);
        tabLayout.setupWithViewPager(viewPager);

        // Iterate over all tabs and set the custom view
        for (int i = 0; i < tabLayout.getTabCount(); i++) {
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            tab.setCustomView(pagerAdapter.getTabView(i));
        }



        for (int i = 0; i < imageResId.length; i++) {
            tabLayout.getTabAt(i).setIcon(imageResId[i]);
        }


    }

    @Override
    public void passTimeFromDialog(String timeAsText) {
        Log.d("Claude Main", "timeAsText " + timeAsText);
//        Log.d("Claude Main", "TimerStatus: " + globalTimerStatus);

//        mTimeFromDialog = timeAsText;
        Bundle bundle = new Bundle();
        bundle.putString("params_timeAsText", timeAsText);
        //bundle.putBoolean("params_mTimerRunning", globalTimerStatus);
        //.putExtras("params_mTimerRunning",globalCountDownTimer);

        //getFragmentManager().beginTransaction().remove(R.id.timer_fragment_container).commit();


        //TimerFragment activeFrag = new TimerFragment();
        //activeFrag.setArguments(bundle);

        //call getSupportFragmentManager().beginTransaction().remove(previousFragment)

        TimerFragment activeFrag = TimerFragment.newInstance(bundle);

        getSupportFragmentManager().beginTransaction()
                .add(activeFrag, "SourceFragTag")
                .commit();

//        getFragmentManager().beginTransaction()
//                .add(R.id.timer_fragment_container, activeFrag, "SourceFragTag")
//                .commit();


        Log.d("claude Main", "Transaction Made");
        //class.TimerFragment


//        .replace(R.id.tv_timer, activeFrag, "SourceFragTag")
//                .replace(R.id.bt_timer_start_pause, activeFrag, "SourceFragTag")
//                .replace(R.id.bt_timer_reset, activeFrag, "SourceFragTag")
//                .replace(R.id.progressbar, activeFrag, "SourceFragTag")
//                .replace(R.id.bt_save_new_preset, activeFrag, "SourceFragTag")
    }

    @Override
    public void sendTimerStatus(boolean truthValue){
        globalTimerStatus = truthValue;
    }

    @Override
    public void sendCountdownTimerObject(CountDownTimer cdTimer){
        globalCountDownTimer = cdTimer;
    }
//
//    public boolean getTimerStatus() {
//        return globalTimerStatus;
//    }
}
